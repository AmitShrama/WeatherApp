import React from "react";
import Tempapp from "./components/Tempapp";
import './App.css';

function App() {
  return (
    <div>
      <Tempapp/>
    </div>
  );
}

export default App;
